(function() {
    'use strict';

    var params = window.localAigraderParams;
    console.log('[aigrader] script loaded, params=', params, 'url=', window.location.href);
    if (!params) {
        return;
    }

    var href = window.location.href;
    var isGraderPage  = href.indexOf('action=grader')  !== -1;  // individual student grader
    var isGradingPage = href.indexOf('action=grading') !== -1;  // all-students table

    if (!isGraderPage && !isGradingPage) {
        return;
    }

    function escapeHtml(text) {
        var d = document.createElement('div');
        d.appendChild(document.createTextNode(text || ''));
        return d.innerHTML;
    }

    // ----------------------------------------------------------------
    // Individual grader page — insert AI grade and feedback into the
    // form at the exact positions requested.
    // ----------------------------------------------------------------
    function renderGraderPanel(item) {
        var gradeRow    = document.getElementById('fitem_id_grade');
        var feedbackRow = document.getElementById('fitem_id_assignfeedbackcomments_editor');

        if (!gradeRow && !feedbackRow) {
            console.log('[aigrader] fitem rows not found after DOM ready');
            return;
        }

        // --- AI Grade widget (inserted before #fitem_id_grade) ---
        if (gradeRow) {
            var gradePanel = document.createElement('div');
            gradePanel.id        = 'local-aigrader-grade';
            gradePanel.className = 'mb-3 row fitem';

            var gradeLabel = document.createElement('div');
            gradeLabel.className = 'col-md-3 col-form-label d-flex pb-0 pr-md-0';
            gradeLabel.innerHTML = '<label class="d-inline word-break"><strong>AI Grade</strong></label>';

            var gradeValue = document.createElement('div');
            gradeValue.className = 'col-md-9 felement';

            if (!item) {
                gradeValue.innerHTML = '<span class="text-muted">&mdash;</span>';
            } else if (item.status === 'pending') {
                gradeValue.innerHTML = '<span class="text-warning">&#9679; Pending</span>';
            } else if (item.status === 'processing') {
                gradeValue.innerHTML = '<span class="text-info">&#9679; Processing\u2026</span>';
            } else if (item.status === 'error') {
                gradeValue.innerHTML = '<span class="text-danger">&#9679; Error</span>';
            } else if (item.grade !== null && item.grade !== undefined) {
                gradeValue.innerHTML = '<strong class="text-primary" style="font-size:1.2em">'
                    + escapeHtml(parseFloat(item.grade).toFixed(1)) + ' / 100</strong>';
            } else {
                gradeValue.innerHTML = '<span class="text-muted">&mdash;</span>';
            }

            gradePanel.appendChild(gradeLabel);
            gradePanel.appendChild(gradeValue);
            gradeRow.parentNode.insertBefore(gradePanel, gradeRow);
        }

        // --- AI Feedback widget (inserted before #fitem_id_assignfeedbackcomments_editor) ---
        if (feedbackRow && item && item.feedback) {
            var fbPanel = document.createElement('div');
            fbPanel.id        = 'local-aigrader-feedback';
            fbPanel.className = 'mb-3 row fitem';

            var fbLabel = document.createElement('div');
            fbLabel.className = 'col-md-3 col-form-label d-flex pb-0 pr-md-0';
            fbLabel.innerHTML = '<label class="d-inline word-break"><strong>AI Feedback</strong></label>';

            var fbValue = document.createElement('div');
            fbValue.className = 'col-md-9 felement';

            var pre = document.createElement('pre');
            pre.className    = 'p-2 rounded border bg-light';
            pre.style.cssText = 'white-space:pre-wrap;font-family:inherit;font-size:0.9em;'
                + 'margin:0;max-height:300px;overflow-y:auto';
            pre.textContent  = item.feedback;

            fbValue.appendChild(pre);
            fbPanel.appendChild(fbLabel);
            fbPanel.appendChild(fbValue);
            feedbackRow.parentNode.insertBefore(fbPanel, feedbackRow);
        }
    }

    // ----------------------------------------------------------------
    // Grading table page — add AI Grade column
    // ----------------------------------------------------------------
    function renderGradingTable(data) {
        var table = document.querySelector('table.generaltable')
            || document.querySelector('#grading-action-form table');

        if (!table) {
            return;
        }

        var thead = table.querySelector('thead tr');
        if (thead) {
            var th = document.createElement('th');
            th.className = 'header c-aigrade';
            th.scope     = 'col';
            th.style.minWidth = '90px';
            th.textContent    = 'AI Grade';
            thead.appendChild(th);
        }

        table.querySelectorAll('tbody tr').forEach(function(row) {
            var td     = document.createElement('td');
            td.className = 'cell c-aigrade';

            var userid = null;

            var cb = row.querySelector('input[name="selectedusers"]');
            if (cb) { userid = parseInt(cb.value, 10); }

            if (!userid && row.dataset && row.dataset.userid) {
                userid = parseInt(row.dataset.userid, 10);
            }

            if (!userid) {
                var a = row.querySelector('a[href*="user/view.php"]');
                if (a) {
                    var m = a.href.match(/[?&]id=(\d+)/);
                    if (m) userid = parseInt(m[1], 10);
                }
            }

            var item = userid ? data[userid] : null;

            if (!item) {
                td.innerHTML = '<span style="color:#999">&mdash;</span>';
            } else if (item.status === 'pending') {
                td.innerHTML = '<span style="color:#e67e22">&#9679; Pending</span>';
            } else if (item.status === 'processing') {
                td.innerHTML = '<span style="color:#2980b9">&#9679; Processing</span>';
            } else if (item.status === 'error') {
                td.innerHTML = '<span style="color:#c0392b">&#9679; Error</span>';
            } else if (item.grade !== null && item.grade !== undefined) {
                var grade = parseFloat(item.grade).toFixed(1);
                var html  = '<strong>' + escapeHtml(grade) + '</strong>';
                if (item.feedback) {
                    var short = item.feedback.length > 80
                        ? item.feedback.substring(0, 80) + '\u2026'
                        : item.feedback;
                    html += '<br><small style="color:#555;font-size:0.8em">' + escapeHtml(short) + '</small>';
                }
                td.innerHTML = html;
            } else {
                td.innerHTML = '<span style="color:#999">&mdash;</span>';
            }

            row.appendChild(td);
        });
    }

    // ----------------------------------------------------------------
    // Fetch AI data and dispatch
    // ----------------------------------------------------------------
    function fetchAndRender() {
        var url = params.wwwroot + '/local/aigrader/ajax.php'
            + '?cmid='    + encodeURIComponent(params.cmid)
            + '&sesskey=' + encodeURIComponent(params.sesskey);

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.onload = function() {
            if (xhr.status !== 200) { return; }
            try {
                var response = JSON.parse(xhr.responseText);
                if (!response || !response.success) { return; }

                if (isGraderPage) {
                    var match  = href.match(/[?&]userid=(\d+)/);
                    var userid = match ? parseInt(match[1], 10) : null;
                    var item   = userid ? response.data[userid] : null;

                    // Grading form is injected dynamically via AJAX —
                    // wait for #fitem_id_grade to appear before rendering.
                    waitForElement('fitem_id_grade', function() {
                        renderGraderPanel(item);
                    });
                } else {
                    renderGradingTable(response.data);
                }
            } catch (e) { /* ignore */ }
        };
        xhr.send();
    }

    /**
     * Wait for an element with the given ID to appear in the DOM,
     * then call callback. Gives up after 15 seconds.
     */
    function waitForElement(id, callback) {
        if (document.getElementById(id)) {
            callback();
            return;
        }
        var observer = new MutationObserver(function() {
            if (document.getElementById(id)) {
                observer.disconnect();
                callback();
            }
        });
        observer.observe(document.body, {childList: true, subtree: true});
        setTimeout(function() { observer.disconnect(); }, 15000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', fetchAndRender);
    } else {
        fetchAndRender();
    }
})();
